﻿namespace OperatorConsole_TargetDetection
{
    partial class FormOpConsole
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormOpConsole));
            this.ButtonStart = new System.Windows.Forms.Button();
            this.OpConsoleTextBox = new System.Windows.Forms.TextBox();
            this.ButtonChange = new System.Windows.Forms.Button();
            this.ButtonDownload = new System.Windows.Forms.Button();
            this.ButtonStop = new System.Windows.Forms.Button();
            this.ButtonView = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ButtonStart
            // 
            this.ButtonStart.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ButtonStart.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ButtonStart.ForeColor = System.Drawing.Color.DarkGreen;
            this.ButtonStart.Location = new System.Drawing.Point(368, 12);
            this.ButtonStart.MaximumSize = new System.Drawing.Size(1000000, 1000000);
            this.ButtonStart.MinimumSize = new System.Drawing.Size(80, 80);
            this.ButtonStart.Name = "ButtonStart";
            this.ButtonStart.Size = new System.Drawing.Size(80, 80);
            this.ButtonStart.TabIndex = 1;
            this.ButtonStart.Text = "Start Program";
            this.ButtonStart.UseVisualStyleBackColor = true;
            this.ButtonStart.Visible = false;
            this.ButtonStart.Click += new System.EventHandler(this.ButtonStart_Click);
            this.ButtonStart.MouseEnter += new System.EventHandler(this.ButtonStart_MouseEnter);
            // 
            // OpConsoleTextBox
            // 
            this.OpConsoleTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.OpConsoleTextBox.BackColor = System.Drawing.Color.Black;
            this.OpConsoleTextBox.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OpConsoleTextBox.ForeColor = System.Drawing.Color.ForestGreen;
            this.OpConsoleTextBox.Location = new System.Drawing.Point(12, 12);
            this.OpConsoleTextBox.MaximumSize = new System.Drawing.Size(1000000, 1000000);
            this.OpConsoleTextBox.MaxLength = 1000000000;
            this.OpConsoleTextBox.MinimumSize = new System.Drawing.Size(350, 422);
            this.OpConsoleTextBox.Multiline = true;
            this.OpConsoleTextBox.Name = "OpConsoleTextBox";
            this.OpConsoleTextBox.ReadOnly = true;
            this.OpConsoleTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.OpConsoleTextBox.Size = new System.Drawing.Size(350, 422);
            this.OpConsoleTextBox.TabIndex = 0;
            this.OpConsoleTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ButtonChange
            // 
            this.ButtonChange.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.ButtonChange.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ButtonChange.Location = new System.Drawing.Point(368, 270);
            this.ButtonChange.MaximumSize = new System.Drawing.Size(1000000, 1000000);
            this.ButtonChange.MinimumSize = new System.Drawing.Size(80, 80);
            this.ButtonChange.Name = "ButtonChange";
            this.ButtonChange.Size = new System.Drawing.Size(80, 80);
            this.ButtonChange.TabIndex = 4;
            this.ButtonChange.Text = "Change Camera Settings";
            this.ButtonChange.UseVisualStyleBackColor = true;
            this.ButtonChange.Visible = false;
            this.ButtonChange.Click += new System.EventHandler(this.ButtonChange_Click);
            this.ButtonChange.MouseEnter += new System.EventHandler(this.ButtonChange_MouseEnter);
            // 
            // ButtonDownload
            // 
            this.ButtonDownload.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.ButtonDownload.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ButtonDownload.Location = new System.Drawing.Point(368, 184);
            this.ButtonDownload.MaximumSize = new System.Drawing.Size(1000000, 1000000);
            this.ButtonDownload.MinimumSize = new System.Drawing.Size(80, 80);
            this.ButtonDownload.Name = "ButtonDownload";
            this.ButtonDownload.Size = new System.Drawing.Size(80, 80);
            this.ButtonDownload.TabIndex = 3;
            this.ButtonDownload.Text = "Download Log and Images";
            this.ButtonDownload.UseVisualStyleBackColor = true;
            this.ButtonDownload.Visible = false;
            this.ButtonDownload.Click += new System.EventHandler(this.ButtonDownload_Click);
            this.ButtonDownload.MouseEnter += new System.EventHandler(this.ButtonDownload_MouseEnter);
            // 
            // ButtonStop
            // 
            this.ButtonStop.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.ButtonStop.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ButtonStop.ForeColor = System.Drawing.Color.Red;
            this.ButtonStop.Location = new System.Drawing.Point(368, 98);
            this.ButtonStop.MaximumSize = new System.Drawing.Size(1000000, 1000000);
            this.ButtonStop.MinimumSize = new System.Drawing.Size(80, 80);
            this.ButtonStop.Name = "ButtonStop";
            this.ButtonStop.Size = new System.Drawing.Size(80, 80);
            this.ButtonStop.TabIndex = 2;
            this.ButtonStop.Text = "Stop Program";
            this.ButtonStop.UseVisualStyleBackColor = true;
            this.ButtonStop.Visible = false;
            this.ButtonStop.Click += new System.EventHandler(this.ButtonStop_Click);
            this.ButtonStop.MouseEnter += new System.EventHandler(this.ButtonStop_MouseEnter);
            // 
            // ButtonView
            // 
            this.ButtonView.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ButtonView.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ButtonView.Location = new System.Drawing.Point(368, 356);
            this.ButtonView.MaximumSize = new System.Drawing.Size(1000000, 1000000);
            this.ButtonView.MinimumSize = new System.Drawing.Size(80, 80);
            this.ButtonView.Name = "ButtonView";
            this.ButtonView.Size = new System.Drawing.Size(80, 80);
            this.ButtonView.TabIndex = 5;
            this.ButtonView.Text = "View Image Feed";
            this.ButtonView.UseVisualStyleBackColor = true;
            this.ButtonView.Visible = false;
            this.ButtonView.Click += new System.EventHandler(this.ButtonView_Click);
            this.ButtonView.MouseEnter += new System.EventHandler(this.ButtonView_MouseEnter);
            // 
            // FormOpConsole
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::OperatorConsole_TargetDetection.Properties.Resources.background1;
            this.ClientSize = new System.Drawing.Size(461, 446);
            this.Controls.Add(this.ButtonStart);
            this.Controls.Add(this.ButtonView);
            this.Controls.Add(this.ButtonStop);
            this.Controls.Add(this.ButtonDownload);
            this.Controls.Add(this.ButtonChange);
            this.Controls.Add(this.OpConsoleTextBox);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(1000000, 1000000);
            this.MinimumSize = new System.Drawing.Size(477, 485);
            this.Name = "FormOpConsole";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Goal Detection - Operator Console";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormOpConsole_FormClosing);
            this.Shown += new System.EventHandler(this.Form1_Shown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ButtonStart;
        private System.Windows.Forms.TextBox OpConsoleTextBox;
        private System.Windows.Forms.Button ButtonChange;
        private System.Windows.Forms.Button ButtonDownload;
        private System.Windows.Forms.Button ButtonStop;
        private System.Windows.Forms.Button ButtonView;
    }
}

