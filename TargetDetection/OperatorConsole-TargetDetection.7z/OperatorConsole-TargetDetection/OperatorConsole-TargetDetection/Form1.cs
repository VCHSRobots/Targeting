﻿using System;
using System.Windows.Forms;
using System.IO;
using System.Media;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading;

namespace OperatorConsole_TargetDetection
{
    public partial class FormOpConsole : Form
    {
        public FormOpConsole()
        {
            InitializeComponent();
        }
        //
        //Functions and stuff and threads, oh my!
        //
        //UDP client for reading inbound data:
        UdpClient receivingUdpClient = new UdpClient(5800);
        //Sets up socket, and ipendpoint settings
        Socket RPi = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
        IPEndPoint endpoint = new IPEndPoint(IPAddress.Parse("10.44.15.14"), 5800);
        //Buffer size
        Byte[] buffer = Encoding.ASCII.GetBytes("1024");
        bool ActiveComm = false;
        //Startup fun!
        void StartupSequence()
        {
            //Startup:
            string text = @"




````````````      ```````````      ````````````
````````````      ```````````      ````````````
````````````      ```````````      ````````````
````````````                       ````````````
````````````                       ````````````
```````````                         ```````````


 
``````            ```````````            ``````
``````            ```````````            ``````
``````            ``LOADING``            ``````
``````            ```````````            ``````
``````            ```````````            ``````



```````````                         ```````````
````````````                       ````````````
````````````                       ````````````
````````````      ```````````      ````````````
````````````      ```````````      ````````````
````````````      ```````````      ````````````
";
            for (int i = 0; i < text.Length; i++)
            {
                OpConsoleTextBox.AppendText(text[i].ToString());
                Thread.Sleep(1);
            }
            OpConsoleTextBox.TextAlign = HorizontalAlignment.Left;
            OpConsoleTextBox.Text = "EpicRobotz - Team 4415\r\n\r\n=====================================\r\n= Goal Detection - Operator Console =\r\n=====================================\r\n\r\n";
            ButtonStart.Visible = true;
            ButtonStop.Visible = true;
            ButtonDownload.Visible = true;
            ButtonChange.Visible = true;
            ButtonView.Visible = true;
        }
        //Textbox update
        delegate void UpdateFromCommInvoker(string returnData);
        void SafeAppendToTextbox(string returnData)
        {
            if (ActiveComm == true)
            {
                OpConsoleTextBox.AppendText(returnData);
            }
        }
        //CommInbound - Listening thread
        void CommInbound()
        {
            //Listens while ActiveComm is true.
            try
            {
                while (ActiveComm == true)
                {
                    Byte[] receiveBytes = receivingUdpClient.Receive(ref endpoint);
                    string returnData = Encoding.ASCII.GetString(receiveBytes);
                    if (OpConsoleTextBox.InvokeRequired)
                    {
                        object[] args = new object[1];
                        args[0] = returnData;
                        OpConsoleTextBox.Invoke(new UpdateFromCommInvoker(SafeAppendToTextbox), args);
                    }
                    else
                    {
                        OpConsoleTextBox.AppendText(returnData);
                    }
                }
            }
            catch (Exception e)
            {
                if (OpConsoleTextBox.InvokeRequired)
                {
                    object[] args = new object[1];
                    args[0] = e.Message;
                    OpConsoleTextBox.Invoke(new UpdateFromCommInvoker(SafeAppendToTextbox), args);
                }
                else
                {
                    OpConsoleTextBox.AppendText(e.Message);
                }
            }
        }
        //CommOutbound
        void CommOutbound(string message)
        {
            //Send message.
            try
            {
                //Attempts to connect.
                RPi.Connect(endpoint);
                RPi.Send(Encoding.ASCII.GetBytes(message));
                OpConsoleTextBox.AppendText("\r\n[INFO] Message sent to Raspberry Pi: " + message);
            }
            catch(Exception e)
            {
                OpConsoleTextBox.AppendText("\r\n[FATL] Unable to send message to Raspberry Pi. Information: " + e.Message);
            }
        }
        //
        //Button Start
        //
        private void ButtonStart_MouseEnter(object sender, EventArgs e)
        {
            //Play button enter sound
            Stream s = Properties.Resources.buttonrollover;
            SoundPlayer player = new SoundPlayer(s);
            player.Play();
        }
        private void ButtonStart_Click(object sender, EventArgs e)
        {
            //Play button press sound
            Stream s = Properties.Resources.buttonclick;
            SoundPlayer player = new SoundPlayer(s);
            player.Play();
            //Sends message to start program, if ActiveComm is false.
            if (ActiveComm == false)
            {
                CommOutbound("/go");
                ActiveComm = true;
                //Start listening thread - that is, "ListenThread" CommInbound().
                Thread ListenThread = new Thread(CommInbound);
                ListenThread.Start();
                OpConsoleTextBox.AppendText("\r\n\r\n===============================================\r\nCONNECTED TO RPI CONSOLE\r\n===============================================\r\n\r\n");
            }
            else
            {
                OpConsoleTextBox.AppendText("\r\n[FATL] Error! The program has allready been started!");
            }
        }
        //
        //Button Stop
        //
        private void ButtonStop_MouseEnter(object sender, EventArgs e)
        {
            //Play button enter sound
            Stream s = Properties.Resources.buttonrollover;
            SoundPlayer player = new SoundPlayer(s);
            player.Play();
        }
        private void ButtonStop_Click(object sender, EventArgs e)
        {
            //Play button press sound
            Stream s = Properties.Resources.buttonclick;
            SoundPlayer player = new SoundPlayer(s);
            player.Play();
            //Sends message to stop program, if ActiveComm is true
            if (ActiveComm == true)
            {
                CommOutbound("/halt");
                ActiveComm = false;
                //Stop listening thread - that is, "ListenThread" CommInbound().
                Thread ListenThread = new Thread(CommInbound);
                ListenThread.Abort();
                OpConsoleTextBox.AppendText("\r\n\r\n===============================================\r\nDISCONNETED FROM RPI CONSOLE\r\n===============================================\r\n\r\n");
            }
            else
            {
                OpConsoleTextBox.AppendText("\r\n[FATL] Error! No communication stream is established; the program is not running! Try clicking \"Start Program\"!");
            }
        }
        //
        //Button Download
        //
        private void ButtonDownload_MouseEnter(object sender, EventArgs e)
        {
            //Play button enter sound
            Stream s = Properties.Resources.buttonrollover;
            SoundPlayer player = new SoundPlayer(s);
            player.Play();
        }
        private void ButtonDownload_Click(object sender, EventArgs e)
        {
            //Play button press sound
            Stream s = Properties.Resources.buttonclick;
            SoundPlayer player = new SoundPlayer(s);
            player.Play();
            //Sends message to download files, if ActiveComm is true
            if (ActiveComm == true)
            {
                CommOutbound("/download");
            }
            else
            {
                OpConsoleTextBox.AppendText("\r\n[FATL] Error! No communication stream is established! Try clicking \"Start Program\"!");
            }
        }
        //
        //Button Change
        //
        private void ButtonChange_MouseEnter(object sender, EventArgs e)
        {
            //Play button enter sound
            Stream s = Properties.Resources.buttonrollover;
            SoundPlayer player = new SoundPlayer(s);
            player.Play();
        }
        private void ButtonChange_Click(object sender, EventArgs e)
        {
            //Play button press sound
            Stream s = Properties.Resources.buttonclick;
            SoundPlayer player = new SoundPlayer(s);
            player.Play();
            //Sends message to send camera settings, if ActiveComm is true
            if (ActiveComm == true)
            {
                CommOutbound("/change");
            }
            else
            {
                OpConsoleTextBox.AppendText("\r\n[FATL] Error! No communication stream is established! Try clicking \"Start Program\"!");
            }
        }
        //
        //Button View
        //
        private void ButtonView_MouseEnter(object sender, EventArgs e)
        {
            //Play button enter sound
            Stream s = Properties.Resources.buttonrollover;
            SoundPlayer player = new SoundPlayer(s);
            player.Play();
        }
        private void ButtonView_Click(object sender, EventArgs e)
        {
            //Play button press sound
            Stream s = Properties.Resources.buttonclick;
            SoundPlayer player = new SoundPlayer(s);
            player.Play();
            //Sends message to start / stop viewing of livefeed, if ActiveComm is true.
            if (ActiveComm == true)
            {
                CommOutbound("/viewgo");
            }
            else
            {
                OpConsoleTextBox.AppendText("\r\n[FATL] Error! No communication stream is established! Try clicking \"Start Program\"!");
            }
        }
        //Form 1 Shown
        private void Form1_Shown(object sender, EventArgs e)
        {
            StartupSequence();
        }
        //Form 1 Closed
        private void FormOpConsole_FormClosing(object sender, FormClosingEventArgs e)
        {
            //Properly shuts down all running threads and closes all open sockets.
            //Stop listening thread - that is, "ListenThread" CommInbound().
            Thread ListenThread = new Thread(CommInbound);
            ListenThread.Abort();
            RPi.Shutdown(SocketShutdown.Both);
            RPi.Close();
        }
    }
}
